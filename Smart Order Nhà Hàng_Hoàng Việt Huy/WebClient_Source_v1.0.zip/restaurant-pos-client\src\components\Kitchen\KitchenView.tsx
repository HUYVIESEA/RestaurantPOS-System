import React, { useEffect, useState } from 'react';
import { orderService } from '../../services/orderService';
import { Order } from '../../types';
import { useSignalR } from '../../contexts/SignalRContext';
import { useToast } from '../../contexts/ToastContext';
import './KitchenView.css';

type KitchenTab = 'pending' | 'processing';

const KitchenView: React.FC = () => {
  const { connection } = useSignalR();
  const { showToast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<KitchenTab>('pending');

  useEffect(() => {
    fetchKitchenOrders();
  }, []);

  // Real-time updates
  useEffect(() => {
    if (connection) {
      const handleNewOrder = (newOrder: Order) => {
        // Only add if status matches kitchen workflow
        if (newOrder.status === 'Pending' || newOrder.status === 'Processing') {
           setOrders(prev => {
             const exists = prev.find(o => o.id === newOrder.id);
             if (exists) return prev.map(o => o.id === newOrder.id ? newOrder : o);
             return [...prev, newOrder];
           });
           if(newOrder.status === 'Pending') playNotificationSound();
        }
      };

      const handleUpdateOrder = (updatedOrder: Order) => {
         // If status is Prepared/Completed/Cancelled, remove from kitchen view
         if (['Prepared', 'Completed', 'Cancelled'].includes(updatedOrder.status)) {
             setOrders(prev => prev.filter(o => o.id !== updatedOrder.id));
         } else {
             // Update in place (e.g. Pending -> Processing)
             setOrders(prev => {
                const exists = prev.find(o => o.id === updatedOrder.id);
                if (exists) return prev.map(o => o.id === updatedOrder.id ? updatedOrder : o);
                return [...prev, updatedOrder];
             });
         }
      };

      connection.on('OrderCreated', handleNewOrder);
      connection.on('OrderUpdated', handleUpdateOrder);

      return () => {
        connection.off('OrderCreated', handleNewOrder);
        connection.off('OrderUpdated', handleUpdateOrder);
      };
    }
  }, [connection]);

  const fetchKitchenOrders = async () => {
    try {
      setLoading(true);
      const allOrders = await orderService.getAll();
      // Filter only relevant statuses
      const kitchenOrders = allOrders.filter(o => 
          o.status === 'Pending' || o.status === 'Processing'
      );
      setOrders(kitchenOrders);
    } catch (err) {
      console.error('Error fetching kitchen data:', err);
      showToast('Lỗi tải dữ liệu bếp', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleStartCooking = async (orderId: number) => {
      try {
          await orderService.updateStatus(orderId, 'Processing');
          // Optimistic
          setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'Processing' } : o));
          showToast('👨‍🍳 Bắt đầu chế biến', 'info');
      } catch (err) {
          showToast('Lỗi cập nhật', 'error');
      }
  };

  const handleFinishCooking = async (orderId: number) => {
      try {
          await orderService.updateStatus(orderId, 'Prepared');
          // Optimistic remove
          setOrders(prev => prev.filter(o => o.id !== orderId));
          showToast('✅ Đã báo xong món', 'success');
      } catch (err) {
          showToast('Lỗi cập nhật', 'error');
      }
  };

  const playNotificationSound = () => {
    try {
      const audio = new Audio('/notification.mp3'); 
      audio.play().catch(() => {});
    } catch (e) {}
  };

  // Filter orders by tab
  const pendingOrders = orders.filter(o => o.status === 'Pending');
  const processingOrders = orders.filter(o => o.status === 'Processing');
  
  const currentOrders = activeTab === 'pending' ? pendingOrders : processingOrders;

  // Sort: Oldest first for Pending? Or newest? KiotViet usually FIFO.
  // Screenshot shows #323, #322, #321. Descending IDs -> Newest first?
  // User screen shot: Bàn 6 (#323) [Top], Bàn 4 (#322), Bàn 3 (#321). 
  // Looks like Newest on Top.
  const sortedOrders = [...currentOrders].sort((a, b) => b.id - a.id);

  if (loading) return <div className="loading-screen">Đang tải dữ liệu...</div>;

  return (
    <div className="kitchen-layout">
        <div className="kitchen-tabs">
            <button 
                className={`kitchen-tab ${activeTab === 'pending' ? 'active' : ''}`}
                onClick={() => setActiveTab('pending')}
            >
                Chờ chế biến ({pendingOrders.length})
            </button>
            <button 
                className={`kitchen-tab ${activeTab === 'processing' ? 'active' : ''}`}
                onClick={() => setActiveTab('processing')}
            >
                Đang chế biến ({processingOrders.length})
            </button>
        </div>

        <div className="kitchen-content">
            {sortedOrders.length === 0 ? (
                <div className="empty-state-kitchen">
                    <i className="fas fa-check-circle"></i>
                    <p>Không có đơn hàng nào</p>
                </div>
            ) : (
                <div className="kitchen-cards-container">
                    {sortedOrders.map(order => (
                        <KitchenCard 
                            key={order.id} 
                            order={order} 
                            isPending={activeTab === 'pending'}
                            onAction={() => activeTab === 'pending' ? handleStartCooking(order.id) : handleFinishCooking(order.id)}
                        />
                    ))}
                </div>
            )}
        </div>
    </div>
  );
};

const KitchenCard: React.FC<{ order: Order; isPending: boolean; onAction: () => void }> = ({ order, isPending, onAction }) => {
    const [elapsed, setElapsed] = useState('');

    useEffect(() => {
        const timer = setInterval(() => {
            const start = new Date(order.orderDate).getTime();
            const now = new Date().getTime();
            const diff = Math.floor((now - start) / 1000);
            const m = Math.floor(diff / 60).toString().padStart(2, '0');
            const s = (diff % 60).toString().padStart(2, '0');
            setElapsed(`${m}:${s}`);
        }, 1000);
        return () => clearInterval(timer);
    }, [order.orderDate]);

    const isTakeaway = order.table?.tableNumber?.toLowerCase().includes('mang') || 
                       order.table?.tableNumber?.toLowerCase().includes('takeaway');
    
    // Smart Title Logic: Show "Bàn X" for DineIn, or "Customer Name" for Takeaway
    let title = '';
    if (isTakeaway) {
        title = order.customerName ? `${order.customerName} (Mang về)` : `Khách mang về #${order.id}`;
    } else {
        title = `Bàn ${order.table?.tableNumber}`;
    }

    return (
        <div className="kv-card">
            <div className="kv-card-header">
                <span className="kv-table-name" style={isTakeaway ? { color: 'var(--warning-dark)' } : {}}>
                    {isTakeaway && <i className="fas fa-shopping-bag" style={{ marginRight: '6px' }}></i>}
                    {title}
                </span>
                <span className="kv-order-id">#{order.id}</span>
            </div>
            <div className="kv-card-time">
                Thời gian: {elapsed}
            </div>
            
            <div className="kv-divider"></div>

            <div className="kv-items-list">
                {order.orderItems?.map((item, idx) => (
                    <div key={idx} className="kv-item">
                        <span className="kv-qty">{item.quantity}x</span>
                        <div className="kv-item-details">
                             <span className="kv-prod-name">{item.product?.name}</span>
                             {item.notes && <div className="kv-note">({item.notes})</div>}
                             {/* Mock modifiers if any (screenshot has 'Che com (Them)') */}
                        </div>
                    </div>
                ))}
            </div>

            <div className="kv-card-footer">
                <button className="kv-btn-action" onClick={onAction}>
                    {isPending ? (
                        <>
                           <i className="fas fa-play" style={{ fontSize: '12px' }}></i> Bắt đầu chế biến
                        </>
                    ) : (
                        <>
                           <i className="fas fa-check"></i> Báo xong
                        </>
                    )}
                </button>
            </div>
        </div>
    );
};

export default KitchenView;
